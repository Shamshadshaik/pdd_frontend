import {
  require_react
} from "./chunk-JRE55LYH.js";
export default require_react();
//# sourceMappingURL=react.js.map
