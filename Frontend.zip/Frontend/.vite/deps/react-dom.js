import {
  require_react_dom
} from "./chunk-EQZXVVGP.js";
import "./chunk-JRE55LYH.js";
export default require_react_dom();
//# sourceMappingURL=react-dom.js.map
